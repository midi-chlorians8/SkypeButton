#include <Arduino.h>
/*
  Arduino Programs Blink

  This sketch demonstrates the Keyboard library.

  For Leonardo and Due boards only.

  When you connect pin 2 to ground, it creates a new window with a key
  combination (CTRL-N), then types in the Blink sketch, then auto-formats the
  text using another key combination (CTRL-T), then uploads the sketch to the
  currently selected Arduino using a final key combination (CTRL-U).

  Circuit:
  - Arduino Leonardo, Micro, Due, LilyPad USB, or Yún
  - wire to connect D2 to ground

  created 5 Mar 2012
  modified 29 Mar 2012
  by Tom Igoe
  modified 3 May 2014
  by Scott Fitzgerald

  This example is in the public domain.

  http://www.arduino.cc/en/Tutorial/KeyboardReprogram
*/
 #include "Keyboard.h"
 void(* resetFunc) (void) = 0;//объявляем функцию reset с адресом 0
void setup() {
  Serial.begin(9600);
  // put your setup code here, to run once:
  pinMode(2, INPUT_PULLUP);
  Keyboard.begin();
  delay( 100   );

  /*
    Keyboard.press(KEY_HOME);
    delay(5);
    Keyboard.release(KEY_HOME);
    delay(500);

    Keyboard.press(KEY_TAB);
    delay(10);
    Keyboard.release(KEY_TAB);
    delay(100);

    Keyboard.press(KEY_TAB);
    delay(10);
    Keyboard.release(KEY_TAB);
    delay(100);

    Keyboard.press(KEY_RETURN);
    delay(10);
    Keyboard.release(KEY_RETURN);
    delay(100);
  */


  // */
}
    
void loop() {
  // put your main code here, to run repeatedly:
  // /*
  while (digitalRead(2) == HIGH) {
    // do nothing until pin 2 goes low
      delay(3); 
  }   
// /*
      
   //   /*
  Keyboard.press(KEY_ESC);
  delay(10);
  Keyboard.release(KEY_ESC);
  delay(15);
//*/

// /*



// Вызов окна скайпа
  Keyboard.press(KEY_LEFT_CTRL);
  delay(5);
  Keyboard.press(KEY_F1);
  delay(5);
  Keyboard.release(KEY_F1);
  delay(5);
  Keyboard.releaseAll();
  delay(400);
// Вызов окна скайпа
  
  Keyboard.press(KEY_LEFT_CTRL);
  delay(5);
  Keyboard.press(KEY_LEFT_SHIFT);
  delay(5);
  Keyboard.press('P');
  delay(5);
  Keyboard.releaseAll();
  
  //  resetFunc(); //вызываем reset

   Keyboard.press(KEY_ESC);
  delay(10);
  Keyboard.release(KEY_ESC);
  delay(15);
//*/

// /*



// Вызов окна скайпа
  Keyboard.press(KEY_LEFT_CTRL);
  delay(5);
  Keyboard.press(KEY_F1);
  delay(5);
  Keyboard.release(KEY_F1);
  delay(5);
  Keyboard.releaseAll();
  delay(400);
// Вызов окна скайпа
  
  Keyboard.press(KEY_LEFT_CTRL);
  delay(5);
  Keyboard.press(KEY_LEFT_SHIFT);
  delay(5);
  Keyboard.press('P');
  delay(5);
  Keyboard.releaseAll();

  Serial.println("I wait");
  delay(1000);
  Serial.println("I NOT wait");

  
/*
  Keyboard.press(KEY_ESC);
  delay(5);   
  Keyboard.release(KEY_ESC);
  delay(500);
 
  Keyboard.press(KEY_ESC);
  delay(5);
  Keyboard.release(KEY_ESC);
  delay(500);

  Keyboard.press(KEY_ESC);
  delay(5);
  Keyboard.release(KEY_ESC);
  delay(500);
  */
//    */

    /*
  Keyboard.press(KEY_HOME);
  delay(5);
  Keyboard.release(KEY_HOME);
  delay(500);

  

  Keyboard.press(KEY_TAB);
  delay(10);
  Keyboard.release(KEY_TAB);
  delay(500);

  Keyboard.press(KEY_TAB);
  delay(10);
  Keyboard.release(KEY_TAB);
    delay(500);

  Keyboard.press(KEY_RETURN);
  delay(10);
  Keyboard.release(KEY_RETURN);
  delay(100);
  */
  //  */


}